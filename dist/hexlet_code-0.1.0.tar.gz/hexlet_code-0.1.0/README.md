### Hexlet tests and linter status:
[![Actions Status](https://github.com/ShvetsovYura/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ShvetsovYura/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cb5c22dcb80af719b513/maintainability)](https://codeclimate.com/github/ShvetsovYura/python-project-49/maintainability)